﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Deus;

namespace Monogame2
{
    class SceneMenu : Scene
    {
        public SceneMenu(MainGame mainGame) : base(mainGame)
        {

        }

        public override void Initialize()
        {
            base.Initialize();
            window.Name("Game by IronPower");

        }
        public override void Load()
        {
            base.Load();

        }
        public override void Unload()
        {

            base.Unload();
        }
        public override void Update(GameTime gameTime)
        {

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);


            base.Draw(gameTime);
            spriteBatch.End();

        }

    }
}
