﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Monogame2;
namespace Deus
{
    public class GameState
    {
        public enum PlayerType { Red, Blue }
        public enum SceneType
        {
            Menu, Gameplay, Gameover
        }
        protected MainGame mainGame;
        public Scene CurrentScene { get; set; }
        public PlayerType VictoriousPlayer;
        public float raceTime;
        public GameState(MainGame mainGame)
        {
            this.mainGame = mainGame;
        }

        public void ChangeScene(SceneType scene)
        {
            if (CurrentScene != null)
            {
                CurrentScene.Unload();
                CurrentScene = null;
            }

            switch (scene)
            {
                case SceneType.Menu:
                    CurrentScene = new SceneMenu(mainGame);
                    break;
                case SceneType.Gameplay:
                    CurrentScene = new SceneGameplay(mainGame);
                    break;
                case SceneType.Gameover:
                    CurrentScene = new SceneGameOver(mainGame);
                    break;
                default:
                    break;
            }
            CurrentScene.Initialize();
            CurrentScene.Load();
        }

    }
}
