﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public class AssetManager
    {
        private ContentManager content;
        public AssetManager(ContentManager content)
        {
            this.content = content;
            dictTexture2D = new Dictionary<string, Texture2D>();
            dictFont = new Dictionary<string, SpriteFont>();
        }
        public void UnloadAllAsset()
        {
            UnloadAllFont();
            UnloadAllTexture2D();
        }

        protected Dictionary<string, Texture2D> dictTexture2D;
        public void LoadTexture2D(string name, string file = "")
        {
            if (!dictTexture2D.ContainsKey(name))
            {
                dictTexture2D.Add(name, content.Load<Texture2D>(file + name));
            }
        }
        public Texture2D GetTexture2D(string name, string file = "")
        {
            LoadTexture2D(name, file);
            return dictTexture2D[name];
        }
        public void UnloadTexture2D(string name)
        {
            if (dictTexture2D.ContainsKey(name))
            {
                dictTexture2D.Remove(name);
            }
        }
        public void UnloadAllTexture2D()
        {
            dictTexture2D.Clear();
        }

        private Dictionary<string, SpriteFont> dictFont;

        public void LoadFont(string name, string file = "")
        {
            if (!dictFont.ContainsKey(name))
            {
                dictFont.Add(name, content.Load<SpriteFont>(file + name));
            }
        }
        public SpriteFont GetFont(string name, string file = "")
        {
            LoadFont(name, file);
            return dictFont[name];
        }
        public void UnloadFont(string name)
        {
            if (dictFont.ContainsKey(name))
            {
                dictFont.Remove(name);
            }
        }
        public void UnloadAllFont()
        {
            dictFont.Clear();
        }
    }
}
