﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public static class Keyboard
    {
        private static KeyboardState oldKeyboardState;
        private static KeyboardState currentKeyboardState;

        public static void Update()
        {
            oldKeyboardState = currentKeyboardState;
            currentKeyboardState = Microsoft.Xna.Framework.Input.Keyboard.GetState();
        }
        public static bool IsKeyDown(Keys key)
        {
            return currentKeyboardState.IsKeyDown(key);
        }
        public static bool IsKeyUp(Keys key)
        {
            return currentKeyboardState.IsKeyUp(key);
        }
        public static bool IsKeyPressed(Keys key)
        {
            return (oldKeyboardState.IsKeyUp(key) && currentKeyboardState.IsKeyDown(key));
        }
        public static bool IsKeyReleased(Keys key)
        {
            return (oldKeyboardState.IsKeyDown(key) && currentKeyboardState.IsKeyUp(key));
        }
    }
}
