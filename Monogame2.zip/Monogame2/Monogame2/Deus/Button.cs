﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public delegate void Function(Button sender);
    public class Button : Sprite
    {
        public bool isHover { get; protected set; }
        public Function OnClick { get; set; }
        public Function OnHover { get; set; }
        public Function NotOnHover { get; set; }
        public Button(Texture2D texture2D, Vector2 position) : base(texture2D, position)
        {

        }

        public override void Update(GameTime gameTime)
        {
            if (hitbox.Contains(Mouse.Position()))
            {
                if (!isHover)
                {
                    isHover = true;
                    //OnHover();
                    Debug.WriteLine("The button is now hover");
                }

            }
            else
            {
                if (isHover)
                {
                    Debug.WriteLine("The Button is no more hover");
                    if (NotOnHover != null)
                        NotOnHover(this);
                }
                isHover = false;

            }
            if (isHover)
            {
                if (Mouse.LeftButtonIsReleased())
                {
                    Debug.WriteLine("Button is clicked");
                    if (OnClick != null)
                        OnClick(this);

                }
                if (OnHover != null)
                    OnHover(this);
            }
            base.Update(gameTime);
        }

    }
}
