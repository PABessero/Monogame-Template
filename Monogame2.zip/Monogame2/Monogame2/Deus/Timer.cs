﻿using Microsoft.Xna.Framework;

namespace Deus
{
    class Timer
    {
        protected float time;
        protected float timeLimite;
        protected bool timeLimiteIsFinish;
        public bool TimeLimiteIsFinish()
        {
            return timeLimiteIsFinish;
        }
        public float Time()
        {
            return time;
        }
        protected bool isStarted;
        public Timer()
        {
            isStarted = false;
            time = 0;
        }
        public void DefineTimeLimite(float timeLimite)
        {
            this.timeLimite = timeLimite;
        }
        public void Start()
        {
            isStarted = true;
        }
        public void Restart()
        {
            isStarted = true;
            time = 0;
            timeLimiteIsFinish = false;
        }
        public void Stop()
        {
            isStarted = false;
        }
        public void Reset()
        {
            isStarted = false;
            time = 0;
            timeLimiteIsFinish = false;
            timeLimite = 0;
        }
        public void Update(GameTime gameTime)
        {
            if (isStarted)
            {
                time += (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (time >= timeLimite)
                    timeLimiteIsFinish = true;
                else if (timeLimiteIsFinish)
                    timeLimiteIsFinish = false;
            }
        }
    }
}
