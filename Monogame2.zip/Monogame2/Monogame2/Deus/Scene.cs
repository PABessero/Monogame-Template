﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public abstract class Scene
    {
        protected MainGame mainGame;
        protected AssetManager assetManager;
        protected SpriteBatch spriteBatch;
        protected GameState gameState;
        protected Window window;

        protected List<IActor> listActor;
        public Scene(MainGame mainGame)
        {
            listActor = new List<IActor>();
            this.mainGame = mainGame;
            assetManager = new AssetManager(mainGame.Content);
            spriteBatch = this.mainGame.spriteBatch;
            gameState = this.mainGame.gameState;
            window = new Window(mainGame);
        }

        public virtual void Initialize()
        {
            window.MouseVisible(false);
        }
        public virtual void Load()
        {

        }

        public virtual void Unload()
        {
            assetManager.UnloadAllAsset();

        }

        public virtual void Update(GameTime gameTime)
        {
            listActor.RemoveAll(item => item.ToRemove == true);

            foreach (IActor actor in listActor)
            {
                actor.Update(gameTime);
            }
        }
        public virtual void Draw(GameTime gameTime)
        {
            foreach (IActor actor in listActor)
            {
                actor.Draw(spriteBatch);
            }
        }
    }
}
