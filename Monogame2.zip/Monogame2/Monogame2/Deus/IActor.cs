﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public interface IActor
    {
        bool ToRemove { get; set; }
        void Hitbox(int width, int height);
        Rectangle Hitbox();
        void Position(float x, float y);
        Vector2 Position();
        void TouchedBy(IActor actor);
        void Update(GameTime gameTime);
        void Draw(SpriteBatch spriteBatch);
    }
}
