﻿using Deus;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public class Sprite : IActor
    {
        public bool ToRemove { get; set; }
        public Color Color { get; set; }
        protected Rectangle hitbox;
        public Rectangle Hitbox() { return hitbox; }
        public void Hitbox(int width, int height) { hitbox.Size = new Point(width, height); }
        protected Vector2 position;
        public void Position(float x, float y) { position.X = x; position.Y = y; }
        public Vector2 Position() { return position; }
        protected Vector2 velocity;
        public Vector2 Velocity() { return velocity; }
        public void Velocity(float x, float y) { velocity.X = x; velocity.Y = y; }
        public Texture2D texture { get; protected set; }
        public Sprite(Texture2D texture2D, Vector2 position)
        {
            ToRemove = false;
            Color = Color.White;
            velocity = new Vector2();
            texture = texture2D;
            this.position = position;
            hitbox = new Rectangle((int)this.position.X, (int)this.position.Y, texture.Width, texture.Height);
        }

        public virtual void Move(float x, float y)
        {
            position.X += x;
            position.Y += y;
        }
        public virtual void TouchedBy(IActor actor)
        {

        }
        public virtual void Update(GameTime gameTime)
        {
            Move(velocity.X * (float)gameTime.ElapsedGameTime.TotalSeconds, velocity.Y * (float)gameTime.ElapsedGameTime.TotalSeconds);
            hitbox.X = (int)position.X;
            hitbox.Y = (int)position.Y;
        }
        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, position, Color);
        }
    }
}
