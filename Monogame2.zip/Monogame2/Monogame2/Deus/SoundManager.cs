﻿using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public static class SoundManager
    {
        private static ContentManager content;

        public static void Initialize(ContentManager content)
        {
            SoundManager.content = content;
            dictSoundEffect = new Dictionary<string, SoundEffect>();
        }
        public static void PlaySong(string name, string file, bool repeating)
        {
            MediaPlayer.Stop();
            Microsoft.Xna.Framework.Media.Song song = content.Load<Microsoft.Xna.Framework.Media.Song>(file + name);
            MediaPlayer.IsRepeating = repeating;
            MediaPlayer.Play(song);
        }
        public static void PlaySong(string name, bool repeating)
        {
            PlaySong(name, "", repeating);
        }
        public static void PlaySong(string name)
        {
            PlaySong(name, "", false);
        }
        public static void StopSong()
        {
            MediaPlayer.Stop();
        }
        private static Dictionary<string, SoundEffect> dictSoundEffect;
        public static void PlaySoundEffect(string name, string file = "")
        {
            LoadSoundEffect(name, file);
            dictSoundEffect[name].Play();
        }
        public static void LoadSoundEffect(string name, string file = "")
        {
            if (!dictSoundEffect.ContainsKey(name))
            {
                dictSoundEffect.Add(name, content.Load<SoundEffect>(file + name));
            }
        }
        public static void UnloadSoundEffect(string name)
        {
            if (dictSoundEffect.ContainsKey(name))
            {
                dictSoundEffect.Remove(name);
            }
        }
        public static void UnloadAllSoundEffect()
        {
            dictSoundEffect.Clear();
        }
    }
}
