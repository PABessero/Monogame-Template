﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace Deus
{
    static public class AssetManagerGlobal
    {
        private static ContentManager content;
        public static void Initialize(ContentManager content)
        {
            AssetManagerGlobal.content = content;
            dictTexture2D = new Dictionary<string, Texture2D>();
            dictFont = new Dictionary<string, SpriteFont>();
        }
        public static void UnloadAllAsset()
        {
            UnloadAllFont();
            UnloadAllTexture2D();
        }

        private static Dictionary<string, Texture2D> dictTexture2D;
        public static void LoadTexture2D(string name, string file = "")
        {
            if (!dictTexture2D.ContainsKey(name))
            {
                dictTexture2D.Add(name, content.Load<Texture2D>(file + name));
            }
        }
        public static Texture2D GetTexture2D(string name, string file = "")
        {
            LoadTexture2D(name, file);
            return dictTexture2D[name];
        }
        public static void UnloadTexture2D(string name)
        {
            if (dictTexture2D.ContainsKey(name))
            {
                dictTexture2D.Remove(name);
            }
        }
        public static void UnloadAllTexture2D()
        {
            dictTexture2D.Clear();
        }

        private static Dictionary<string, SpriteFont> dictFont;

        public static void LoadFont(string name, string file = "")
        {
            if (!dictFont.ContainsKey(name))
            {
                dictFont.Add(name, content.Load<SpriteFont>(file + name));
            }
        }
        public static SpriteFont GetFont(string name, string file = "")
        {
            LoadFont(name, file);
            return dictFont[name];
        }
        public static void UnloadFont(string name)
        {
            if (dictFont.ContainsKey(name))
            {
                dictFont.Remove(name);
            }
        }
        public static void UnloadAllFont()
        {
            dictFont.Clear();
        }
    }
}
