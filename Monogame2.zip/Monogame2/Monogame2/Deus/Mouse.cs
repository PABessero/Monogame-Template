﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Deus
{
    public static class Mouse
    {
        static MouseState oldMouseState;
        static MouseState currentMouseState;

        public static void Update()
        {

            oldMouseState = currentMouseState;
            currentMouseState = Microsoft.Xna.Framework.Input.Mouse.GetState();
        }
        public static Point Position()
        {
            return currentMouseState.Position;
        }
        public static void Position(int x, int y)
        {
            Microsoft.Xna.Framework.Input.Mouse.SetPosition(x, y);
        }
        public static void SetCursor(Texture2D texture, int origineX, int origineY)
        {
            Microsoft.Xna.Framework.Input.Mouse.SetCursor(MouseCursor.FromTexture2D(texture, origineX, origineY));
        }
        public static bool LeftButtonIsDown()
        {
            return currentMouseState.LeftButton == ButtonState.Pressed;
        }
        public static bool LeftButtonIsUp()
        {
            return currentMouseState.LeftButton == ButtonState.Released;
        }
        public static bool LeftButtonIsPressed()
        {
            return (oldMouseState.LeftButton == ButtonState.Released && currentMouseState.LeftButton == ButtonState.Pressed);
        }
        public static bool LeftButtonIsReleased()
        {
            return (oldMouseState.LeftButton == ButtonState.Pressed && currentMouseState.LeftButton == ButtonState.Released);
        }
        public static bool RightButtonIsDown()
        {
            return currentMouseState.RightButton == ButtonState.Pressed;
        }
        public static bool RightButtonIsUp()
        {
            return currentMouseState.RightButton == ButtonState.Released;
        }
        public static bool RightButtonIsPressed()
        {
            return (oldMouseState.RightButton == ButtonState.Released && currentMouseState.RightButton == ButtonState.Pressed);
        }
        public static bool RightButtonIsReleased()
        {
            return (oldMouseState.RightButton == ButtonState.Pressed && currentMouseState.RightButton == ButtonState.Released);
        }
    }
}
