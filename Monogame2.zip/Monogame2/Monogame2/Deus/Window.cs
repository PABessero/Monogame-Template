﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public class Window
    {
        public Window(MainGame game)
        {
            this.game = game;
        }
        protected MainGame game;
        public enum WindowPosition { Center }
        public void Size(Point size)
        {
            game.graphics.PreferredBackBufferWidth = size.X;
            game.graphics.PreferredBackBufferHeight = size.Y;
            game.graphics.ApplyChanges();
        }
        public Point Size()
        {
            return new Point(game.graphics.PreferredBackBufferWidth, game.graphics.PreferredBackBufferHeight);
        }
        public void FullScreen(bool isFullScreen)
        {
            game.graphics.IsFullScreen = isFullScreen;
            game.graphics.ApplyChanges();
        }
        public bool FullScreen()
        {
            return game.graphics.IsFullScreen;
        }
        public void ChangeWindowSetting(string windowName, Point WindowSize, bool mouseIsVisible = false, bool fullScreen = false)
        {
            MouseVisible(mouseIsVisible);
            Name(windowName);
            Size(WindowSize);
            FullScreen(fullScreen);
        }
        public void MouseVisible(bool mouseIsVisible)
        {
            game.IsMouseVisible = mouseIsVisible;
        }
        public bool MouseVisible()
        {
            return game.IsMouseVisible;
        }
        public void Name(string name)
        {
            game.Window.Title = name;
        }
        public string Name()
        {
            return game.Window.Title;
        }
        public void Exit()
        {
            game.Exit();
        }
        public void ClearColor(Color color)
        {
            game.clearColor = color;
        }
        public Color ClearColor()
        {
            return game.clearColor;
        }

        protected Point position;
        public void Position(Point position)
        {
            game.Window.Position = position;
        }
        public void Position(WindowPosition windowPosition)
        {
            switch (windowPosition)
            {
                case WindowPosition.Center:
                    Position(new Point(game.graphics.GraphicsDevice.DisplayMode.Width / 2 - Size().X / 2, game.GraphicsDevice.DisplayMode.Height / 2 - Size().Y / 2));
                    break;
                default:
                    Debug.Fail("This type of position dosn't exist.");
                    break;
            }
            game.graphics.ApplyChanges();
        }
        public Point Position()
        {
            return game.Window.Position;
        }

    }
}
