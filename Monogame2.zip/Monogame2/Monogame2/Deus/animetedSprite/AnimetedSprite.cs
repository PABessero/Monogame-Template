﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Deus
{
    class AnimetedSprite : Sprite
    {
        public AnimetedSprite(Texture2D texture2D, Vector2 position, Point frameSize) : base(texture2D, position)
        {
            sourceRectangle = new Rectangle(0, 0, frameSize.X, frameSize.Y);
            dictAnimation = new Dictionary<string, Animation>();
            hitbox.Size = frameSize;
        }
        protected Rectangle sourceRectangle;
        protected Dictionary<string, Animation> dictAnimation;
        protected string currentAnimation;
        public string CurrentAnimation() { return currentAnimation; }
        protected int currentFrame;
        protected float chronoAnimation;
        protected bool isLooping;
        public bool AnimationIsFinish { get; set; }

        public void AddAnimation(string name, Animation animation, bool playThisAnimation = false, bool isLooping = false)
        {
            if (!dictAnimation.ContainsKey(name))
                dictAnimation.Add(name, animation);
            else
                Debug.Fail(name + " animation have been created twice !");

            if (playThisAnimation)
                PlayAnimation(name, isLooping);
        }
        public void PlayAnimation(string animationName, bool isLooping = false)
        {
            if (dictAnimation.ContainsKey(animationName))
                currentAnimation = animationName;
            else
                Debug.Fail(animationName + " animation doesn't exist !");
            AnimationIsFinish = false;
            this.isLooping = isLooping;
            currentFrame = 0;
            sourceRectangle.X = dictAnimation[currentAnimation].ListFrame[currentFrame] * sourceRectangle.Width;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            chronoAnimation += (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (chronoAnimation >= dictAnimation[currentAnimation].Speed)
            {
                chronoAnimation = 0;
                currentFrame += 1;

                if (dictAnimation[currentAnimation].ListFrame.Count <= currentFrame)
                {
                    currentFrame -= 1;
                    Debug.WriteLine("This animation is finish !");

                    if (isLooping)
                        currentFrame = 0;
                    AnimationIsFinish = true;
                }
                else
                    AnimationIsFinish = false;
                sourceRectangle.X = dictAnimation[currentAnimation].ListFrame[currentFrame] * sourceRectangle.Width;
            }
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, position, sourceRectangle, Color);
        }
    }
}
