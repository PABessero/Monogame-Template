﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    class Animation
    {
        public Animation(List<short> listFrame, float speed)
        {
            if (listFrame.Count == 0)
                Debug.Fail("This animation have no frame !");
            ListFrame = listFrame;
            Speed = speed;
        }
        readonly public List<short> ListFrame;
        readonly public float Speed;
    }
}
