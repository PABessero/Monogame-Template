﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    public static class Collision
    {
        public static bool CollideByBox(IActor a1, IActor a2)
        {
            return a1.Hitbox().Intersects(a2.Hitbox());
        }
    }
}
