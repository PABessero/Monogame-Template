﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deus
{
    static class Random
    {
        private static System.Random random;
        static Random()
        {
            random = new System.Random(DateTime.Now.Millisecond);
        }
        public static int GetInt(int maxValue)
        {
            return random.Next(maxValue + 1);
        }
        public static int GetInt(int minValue, int maxValue)
        {
            return random.Next(minValue, maxValue + 1);
        }
        public static void SetRandomSeed(int seed)
        {
            random = new System.Random(seed);
        }
    }
}
