﻿namespace Deus
{
    class Web
    {
        public static void OpenLink(string name)
        {
            System.Diagnostics.Process.Start(name);
        }
    }
}
