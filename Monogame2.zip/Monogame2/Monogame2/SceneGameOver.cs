﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Deus;

namespace Monogame2
{
    public class SceneGameOver : Scene
    {
        public SceneGameOver(MainGame mainGame) : base(mainGame)
        {

        }
        public override void Initialize()
        {
            base.Initialize();

        }
        public override void Load()
        {
            base.Load();

        }
        public override void Unload()
        {
            base.Unload();
        }
        public override void Update(GameTime gameTime)
        {

            base.Update(gameTime);
        }
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);



            base.Draw(gameTime);
            spriteBatch.End();
        }

    }
}
